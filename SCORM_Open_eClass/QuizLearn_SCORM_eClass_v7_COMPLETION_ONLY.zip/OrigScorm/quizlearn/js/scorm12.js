/* QuizLearn — SCORM 1.2 adapter for Open eClass */
(function () {
    "use strict";

    let API = null;
    let finished = false;

    function findAPI(win) {
        let attempts = 0;
        while (win && attempts < 50) {
            try {
                if (win.API) return win.API;
                if (win.parent && win.parent !== win) win = win.parent;
                else break;
            } catch (e) { break; }
            attempts++;
        }
        try {
            if (window.opener) {
                win = window.opener;
                attempts = 0;
                while (win && attempts < 50) {
                    if (win.API) return win.API;
                    if (win.parent && win.parent !== win) win = win.parent;
                    else break;
                    attempts++;
                }
            }
        } catch (e) {}
        return null;
    }

    function init() {
        if (API) return true;
        API = findAPI(window);
        if (!API) {
            console.warn("QuizLearn SCORM: LMS API not found; standalone mode.");
            return false;
        }

        // IMPORTANT: index.html (the SCO launcher) has already called LMSInitialize.
        // Do not initialize the same SCORM session a second time from the iframe.
        try {
            const status = API.LMSGetValue("cmi.core.lesson_status");
            if (!status || status === "not attempted") {
                API.LMSSetValue("cmi.core.lesson_status", "incomplete");
                API.LMSCommit("");
            }
            console.log("QuizLearn SCORM: using initialized Open eClass session.");
            return true;
        } catch (e) {
            console.error("QuizLearn SCORM init error:", e);
            return false;
        }
    }

    function setValue(name, value) {
        const result = API.LMSSetValue(name, String(value));

        return String(result).toLowerCase() === "true";
    }

    function reportResult(score, total, percent) {
        if (!API) return false;

        try {
            // Completion-only SCORM reporting:
            // QuizLearn keeps the detailed score/results internally.
            // Open eClass receives only that the activity was completed.
            const status = setValue("cmi.core.lesson_status", "completed");
            const commit = API.LMSCommit("");

            return status && String(commit).toLowerCase() === "true";
        } catch (err) {
            console.warn("QuizLearn SCORM completion report failed:", err);
            return false;
        }
    }

    function finish() {
        if (finished || !API) return;
        try {
            API.LMSCommit("");
            API.LMSFinish("");
            finished = true;
        } catch (e) {
            console.error("QuizLearn SCORM finish error:", e);
        }
    }

    window.QuizLearnSCORM = { init, reportResult, finish };
    window.addEventListener("load", init);
    window.addEventListener("pagehide", finish);
})();
